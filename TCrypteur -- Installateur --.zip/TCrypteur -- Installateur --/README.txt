 -- Merci pour votre téléchargement ! --

Pour installer TCrypteur dans votre ordinateur,
Double-cliquez sur le fichier "Installation TCrypteur.bat"

Pour de prochaines mises à jour, visitez https://github.com/Timothee-C/TCrypteur
 -- Logiciel codé en python --

Pour désinstaller TCrypteur de l'ordinateur, téléchargez le
désinstallateur disponible sur https://github.com/Timothee-C/TCrypteur